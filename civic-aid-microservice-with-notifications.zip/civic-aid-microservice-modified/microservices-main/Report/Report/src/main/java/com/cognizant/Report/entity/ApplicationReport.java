package com.cognizant.Report.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "application_report")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationReport {

    @Id
    private Long applicationId;

    @Column(nullable = false)
    private Long programId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ApplicationStatus status;

    public enum ApplicationStatus {
        SUBMITTED,
        APPROVED,
        REJECTED,
        DISBURSED
    }
}