package com.cognizant.Report.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

@FeignClient(name = "compliance-service", path = "/compliance")
public interface ComplianceFeignClient {

    @GetMapping("/stats")
    Map<String, Object> getComplianceStats();
}