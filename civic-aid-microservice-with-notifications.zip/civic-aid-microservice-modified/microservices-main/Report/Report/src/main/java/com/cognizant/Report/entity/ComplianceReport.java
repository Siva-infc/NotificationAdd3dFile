package com.cognizant.Report.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "compliance_report")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComplianceReport {

    @Id
    private Long recordId;

    @Column(nullable = false)
    private Long entityId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EntityType entityType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ComplianceResult result;

    public enum EntityType {
        APPLICATION,
        PROGRAM,
        DISBURSEMENT,
        PAYMENT
    }

    public enum ComplianceResult {
        COMPLIANT,
        NON_COMPLIANT,
        UNDER_REVIEW
    }
}
