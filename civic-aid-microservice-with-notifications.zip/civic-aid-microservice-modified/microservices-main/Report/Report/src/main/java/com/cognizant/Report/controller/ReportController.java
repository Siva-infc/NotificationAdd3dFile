package com.cognizant.Report.controller;

import com.cognizant.Report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        return ResponseEntity.ok(reportService.getDashboardStats());
    }

    @GetMapping("/applications")
    public ResponseEntity<Map<String, Object>> getApplicationStats() {
        return ResponseEntity.ok(reportService.getApplicationStats());
    }

    @GetMapping("/disbursements")
    public ResponseEntity<Map<String, Object>> getDisbursementStats() {
        return ResponseEntity.ok(reportService.getDisbursementStats());
    }

    @GetMapping("/compliance")
    public ResponseEntity<Map<String, Object>> getComplianceStats() {
        return ResponseEntity.ok(reportService.getComplianceStats());
    }

    @GetMapping("/programs/{programId}")
    public ResponseEntity<Map<String, Object>> getProgramStats(
            @PathVariable Long programId) {
        return ResponseEntity.ok(reportService.getProgramStats(programId));
    }
}
