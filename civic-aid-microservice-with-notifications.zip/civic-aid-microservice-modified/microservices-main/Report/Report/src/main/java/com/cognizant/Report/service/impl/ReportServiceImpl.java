package com.cognizant.Report.service.impl;

import com.cognizant.Report.entity.ApplicationReport;
import com.cognizant.Report.entity.DisbursementReport;
import com.cognizant.Report.entity.ProgramReport;
import com.cognizant.Report.entity.ComplianceReport;
import com.cognizant.Report.exception.ResourceNotFoundException;
import com.cognizant.Report.repository.ApplicationRepo;
import com.cognizant.Report.repository.DisbursementRepo;
import com.cognizant.Report.repository.ProgramRepo;
import com.cognizant.Report.repository.ComplianceRepo;
import com.cognizant.Report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ReportServiceImpl implements ReportService {

    private final ApplicationRepo applicationReportRepository;
    private final DisbursementRepo disbursementReportRepository;
    private final ProgramRepo programReportRepository;
    private final ComplianceRepo complianceReportRepository;

    @Override
    public Map<String, Object> getDashboardStats() {

        Map<String, Object> stats = new LinkedHashMap<>();

        stats.put("totalApplications",
                applicationReportRepository.count());

        stats.put("approvedApplications",
                applicationReportRepository.countByStatus(
                        ApplicationReport.ApplicationStatus.APPROVED));

        stats.put("totalPrograms",
                programReportRepository.count());

        BigDecimal totalDisbursed =
                disbursementReportRepository.sumCompletedAmounts();

        stats.put("totalDisbursedAmount",
                totalDisbursed != null ? totalDisbursed : BigDecimal.ZERO);

        return stats;
    }

    @Override
    public Map<String, Object> getApplicationStats() {

        Map<String, Object> stats = new LinkedHashMap<>();

        for (ApplicationReport.ApplicationStatus status
                : ApplicationReport.ApplicationStatus.values()) {

            stats.put(
                    status.name().toLowerCase(),
                    applicationReportRepository.countByStatus(status)
            );
        }

        return stats;
    }

    @Override
    public Map<String, Object> getDisbursementStats() {

        Map<String, Object> stats = new LinkedHashMap<>();

        for (DisbursementReport.DisbursementStatus status
                : DisbursementReport.DisbursementStatus.values()) {

            stats.put(
                    status.name().toLowerCase(),
                    disbursementReportRepository.countByStatus(status)
            );
        }

        stats.put("totalAmountDisbursed",
                disbursementReportRepository.sumCompletedAmounts());

        return stats;
    }

    @Override
    public Map<String, Object> getComplianceStats() {

        Map<String, Object> stats = new LinkedHashMap<>();

        for (ComplianceReport.ComplianceResult result
                : ComplianceReport.ComplianceResult.values()) {

            stats.put(
                    result.name().toLowerCase(),
                    complianceReportRepository.countByResult(result)
            );
        }

        return stats;
    }

    @Override
    public Map<String, Object> getProgramStats(Long programId) {

        programReportRepository.findById(programId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Program", programId));

        Map<String, Object> stats = new LinkedHashMap<>();

        stats.put("programId", programId);

        stats.put("applications",
                applicationReportRepository.countByProgramId(programId));

        stats.put("disbursedAmount",
                disbursementReportRepository
                        .sumCompletedAmountsByProgram(programId));

        return stats;
    }
}