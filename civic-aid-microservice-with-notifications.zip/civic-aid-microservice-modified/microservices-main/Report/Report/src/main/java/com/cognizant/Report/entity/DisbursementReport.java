package com.cognizant.Report.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "disbursement_report")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DisbursementReport {

    @Id
    private Long disbursementId;

    @Column(nullable = false)
    private Long programId;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DisbursementStatus status;

    public enum DisbursementStatus {
        PENDING,
        COMPLETED
    }
}
