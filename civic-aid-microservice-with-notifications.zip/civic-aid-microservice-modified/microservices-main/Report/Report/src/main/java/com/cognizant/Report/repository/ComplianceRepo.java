package com.cognizant.Report.repository;

import com.cognizant.Report.entity.ComplianceReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComplianceRepo
        extends JpaRepository<ComplianceReport, Long> {

    long countByResult(ComplianceReport.ComplianceResult result);
}
