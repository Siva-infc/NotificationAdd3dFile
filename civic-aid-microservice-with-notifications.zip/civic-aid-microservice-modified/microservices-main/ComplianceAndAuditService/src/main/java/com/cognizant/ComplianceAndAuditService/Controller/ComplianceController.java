package com.cognizant.ComplianceAndAuditService.Controller;

import com.cognizant.ComplianceAndAuditService.Request.ComplianceRecordRequest;
import com.cognizant.ComplianceAndAuditService.Response.ComplianceRecordResponse;
import com.cognizant.ComplianceAndAuditService.Entity.ComplianceRecord;
import com.cognizant.ComplianceAndAuditService.Service.ComplianceService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/compliance")
@RequiredArgsConstructor
public class ComplianceController {

    private final ComplianceService complianceService;

    @PostMapping
    public ResponseEntity<ComplianceRecordResponse> createRecord(
            @RequestParam Long reviewerId,
            @Valid @RequestBody ComplianceRecordRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(complianceService.createRecord(reviewerId, request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComplianceRecordResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(complianceService.getById(id));
    }

    @GetMapping("/entity")
    public ResponseEntity<List<ComplianceRecordResponse>> getByEntity(
            @RequestParam Long entityId,
            @RequestParam ComplianceRecord.EntityType entityType) {

        return ResponseEntity.ok(
                complianceService.getByEntity(entityId, entityType));
    }

    @GetMapping
    public ResponseEntity<Page<ComplianceRecordResponse>> getAll(
            Pageable pageable,
            @RequestParam(required = false)
            ComplianceRecord.ComplianceResult result) {

        return (result != null)
                ? ResponseEntity.ok(
                complianceService.getByResult(result, pageable))
                : ResponseEntity.ok(
                complianceService.getAll(pageable));
    }
}