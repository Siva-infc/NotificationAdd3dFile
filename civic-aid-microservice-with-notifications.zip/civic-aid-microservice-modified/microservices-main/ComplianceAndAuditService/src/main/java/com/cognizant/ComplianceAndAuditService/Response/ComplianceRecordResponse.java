package com.cognizant.ComplianceAndAuditService.Response;

import com.cognizant.ComplianceAndAuditService.Entity.ComplianceRecord;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComplianceRecordResponse {

    private Long complianceId;
    private Long entityId;
    private ComplianceRecord.EntityType entityType;
    private ComplianceRecord.ComplianceResult result;
    private String notes;
    private Long reviewedById;
    private LocalDateTime createdAt;
}
