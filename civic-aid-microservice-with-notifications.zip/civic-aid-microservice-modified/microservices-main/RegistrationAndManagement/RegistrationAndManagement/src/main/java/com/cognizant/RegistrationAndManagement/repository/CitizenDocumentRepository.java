package com.cognizant.RegistrationAndManagement.repository;

import com.cognizant.RegistrationAndManagement.entity.CitizenDocument;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CitizenDocumentRepository
        extends JpaRepository<CitizenDocument, Long> {

    List<CitizenDocument> findByCitizen_CitizenId(Long citizenId);

    List<CitizenDocument> findByCitizen_CitizenIdAndDocType(
            Long citizenId,
            CitizenDocument.DocType docType
    );

    List<CitizenDocument> findByVerificationStatus(
            CitizenDocument.VerificationStatus status
    );

    boolean existsByCitizen_CitizenIdAndDocType(
            Long citizenId,
            CitizenDocument.DocType docType
    );
}