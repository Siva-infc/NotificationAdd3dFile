package com.cognizant.RegistrationAndManagement.service;

import com.cognizant.RegistrationAndManagement.entity.CitizenDocument;
import com.cognizant.RegistrationAndManagement.request.CitizenDocumentRequest;
import com.cognizant.RegistrationAndManagement.response.CitizenDocumentResponse;

import java.util.List;

public interface CitizenDocumentService {

    CitizenDocumentResponse uploadDocument(
            CitizenDocumentRequest request
    );

    CitizenDocumentResponse getDocumentById(Long id);

    List<CitizenDocumentResponse> getDocumentsByCitizen(
            Long citizenId
    );

    CitizenDocumentResponse verifyDocument(
            Long id,
            CitizenDocument.VerificationStatus status,
            String notes
    );

    void deleteDocument(Long id);
}