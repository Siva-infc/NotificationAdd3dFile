package com.cognizant.RegistrationAndManagement.controller;

import com.cognizant.RegistrationAndManagement.entity.CitizenDocument;
import com.cognizant.RegistrationAndManagement.request.CitizenDocumentRequest;
import com.cognizant.RegistrationAndManagement.response.CitizenDocumentResponse;
import com.cognizant.RegistrationAndManagement.service.CitizenDocumentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/documents")
@RequiredArgsConstructor
public class CitizenDocumentController {

    private final CitizenDocumentService documentService;

    @PostMapping
    @PreAuthorize("hasAnyRole('CITIZEN')")
    public ResponseEntity<CitizenDocumentResponse> uploadDocument(
            @Valid @RequestBody CitizenDocumentRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(documentService.uploadDocument(request));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<CitizenDocumentResponse> getDocumentById(
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(
                documentService.getDocumentById(id)
        );
    }

    @GetMapping("/citizen/{citizenId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<CitizenDocumentResponse>> getDocumentsByCitizen(
            @PathVariable Long citizenId
    ) {
        return ResponseEntity.ok(
                documentService.getDocumentsByCitizen(citizenId)
        );
    }

    @PatchMapping("/{id}/verify")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<CitizenDocumentResponse> verifyDocument(
            @PathVariable Long id,
            @RequestParam CitizenDocument.VerificationStatus status,
            @RequestParam(required = false) String notes
    ) {
        return ResponseEntity.ok(
                documentService.verifyDocument(id, status, notes)
        );
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<String> deleteDocument(
            @PathVariable Long id
    ) {
        documentService.deleteDocument(id);
        return ResponseEntity.ok("Document deleted");
    }
}