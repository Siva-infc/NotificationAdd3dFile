package com.cognizant.RegistrationAndManagement.response;

import com.cognizant.RegistrationAndManagement.entity.CitizenDocument;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CitizenDocumentResponse {

    private Long documentId;
    private Long citizenId;
    private String citizenName;
    private CitizenDocument.DocType docType;
    private String fileUri;
    private LocalDateTime uploadedDate;
    private CitizenDocument.VerificationStatus verificationStatus;
    private String verificationNotes;
}