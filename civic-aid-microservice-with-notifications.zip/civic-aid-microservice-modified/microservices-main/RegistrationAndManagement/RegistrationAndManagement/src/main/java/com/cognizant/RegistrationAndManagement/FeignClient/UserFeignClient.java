package com.cognizant.RegistrationAndManagement.FeignClient;

import com.cognizant.RegistrationAndManagement.response.RegisterResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service")
public interface UserFeignClient {

        @GetMapping("/users/{id}")
        RegisterResponseDto getUserById(@PathVariable("id") Long id);

//        @GetMapping("/users/email/{email}")
//        UserDto getUserByEmail(@PathVariable("email") String email);
}

