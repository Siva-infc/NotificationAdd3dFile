package com.cognizant.RegistrationAndManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationAndManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
