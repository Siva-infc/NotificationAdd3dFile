package com.cognizant.ApplicationAndEligibility.repository;

import com.cognizant.ApplicationAndEligibility.entity.EligibilityCheck;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EligibilityCheckRepository
        extends JpaRepository<EligibilityCheck, Long> {

    List<EligibilityCheck> findByApplication_ApplicationId(
            Long applicationId
    );

    List<EligibilityCheck> findByOfficerId(
            Long officerId
    );

    Optional<EligibilityCheck>
    findTopByApplication_ApplicationIdOrderByDateDesc(
            Long applicationId
    );

    long countByResult(
            EligibilityCheck.CheckResult result
    );
}