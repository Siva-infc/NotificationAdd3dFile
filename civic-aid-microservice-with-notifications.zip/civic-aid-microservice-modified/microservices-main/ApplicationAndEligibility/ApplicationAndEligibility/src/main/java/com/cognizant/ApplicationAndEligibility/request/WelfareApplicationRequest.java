package com.cognizant.ApplicationAndEligibility.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WelfareApplicationRequest {

    @NotNull
    private Long citizenId;

    @NotNull
    private Long programId;

    private Long schemeId;

    private String remarks;
}