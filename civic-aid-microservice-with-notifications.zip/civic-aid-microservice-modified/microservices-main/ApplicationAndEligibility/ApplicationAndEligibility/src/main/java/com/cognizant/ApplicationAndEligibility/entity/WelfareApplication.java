package com.cognizant.ApplicationAndEligibility.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "welfare_applications")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WelfareApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    /** Reference to Citizen microservice */
    @Column(nullable = false)
    private Long citizenId;

    /** Reference to Program microservice */
    @Column(nullable = false)
    private Long programId;

    /** Reference to Scheme microservice (optional) */
    private Long schemeId;

    @CreationTimestamp
    private LocalDateTime submittedDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ApplicationStatus status = ApplicationStatus.SUBMITTED;

    @Column(columnDefinition = "TEXT")
    private String remarks;

    @OneToMany(
            mappedBy = "application",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY
    )
    private List<EligibilityCheck> eligibilityChecks;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum ApplicationStatus {
        SUBMITTED,
        UNDER_REVIEW,
        ELIGIBLE,
        INELIGIBLE,
        APPROVED,
        REJECTED,
        DISBURSED,
        CLOSED
    }
}