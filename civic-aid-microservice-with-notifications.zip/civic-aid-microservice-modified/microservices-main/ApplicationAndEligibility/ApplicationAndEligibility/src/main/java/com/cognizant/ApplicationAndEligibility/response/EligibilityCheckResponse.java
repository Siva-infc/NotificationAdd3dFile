package com.cognizant.ApplicationAndEligibility.response;

import com.cognizant.ApplicationAndEligibility.entity.EligibilityCheck;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EligibilityCheckResponse {

    private Long checkId;
    private Long applicationId;
    private Long officerId;
    private EligibilityCheck.CheckResult result;
    private LocalDateTime date;
    private String notes;
}