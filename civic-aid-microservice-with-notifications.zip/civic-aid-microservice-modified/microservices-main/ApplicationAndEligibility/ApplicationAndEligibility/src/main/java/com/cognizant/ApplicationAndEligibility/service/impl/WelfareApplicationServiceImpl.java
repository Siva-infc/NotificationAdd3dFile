package com.cognizant.ApplicationAndEligibility.service.impl;

import com.cognizant.ApplicationAndEligibility.FeignClient.NotificationFeignClient;
import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import com.cognizant.ApplicationAndEligibility.repository.WelfareApplicationRepository;
import com.cognizant.ApplicationAndEligibility.request.NotificationRequest;
import com.cognizant.ApplicationAndEligibility.request.WelfareApplicationRequest;
import com.cognizant.ApplicationAndEligibility.response.WelfareApplicationResponse;
import com.cognizant.ApplicationAndEligibility.service.WelfareApplicationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class WelfareApplicationServiceImpl implements WelfareApplicationService {

    private final WelfareApplicationRepository repository;
    private final NotificationFeignClient notificationFeignClient;

    @Override
    @Transactional
    public WelfareApplicationResponse submitApplication(WelfareApplicationRequest request) {
        log.info("Submitting application citizenId={}, programId={}",
                request.getCitizenId(), request.getProgramId());

        if (repository.existsByCitizenIdAndProgramId(
                request.getCitizenId(),
                request.getProgramId()
        )) {
            log.warn("Duplicate application attempt citizenId={}, programId={}",
                    request.getCitizenId(), request.getProgramId());
            throw new IllegalStateException("Application already exists for this program");
        }

        WelfareApplication app = WelfareApplication.builder()
                .citizenId(request.getCitizenId())
                .programId(request.getProgramId())
                .schemeId(request.getSchemeId())
                .remarks(request.getRemarks())
                .status(WelfareApplication.ApplicationStatus.SUBMITTED)
                .build();

        WelfareApplication saved = repository.save(app);
        log.info("Application created with id={}", saved.getApplicationId());

        notificationFeignClient.sendNotification(NotificationRequest.builder()
                .recipientId(saved.getCitizenId())
                .entityId(saved.getApplicationId())
                .message("Your welfare application (ID: " + saved.getApplicationId() + ") for program (ID: " + saved.getProgramId() + ") has been submitted successfully.")
                .category("APPLICATION")
                .build());

        return map(saved);
    }

    @Override
    public WelfareApplicationResponse getApplicationById(Long id) {
        log.debug("Fetching application id={}", id);

        WelfareApplication app = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        return map(app);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByCitizen(
            Long citizenId,
            Pageable pageable
    ) {
        return repository.findByCitizenId(citizenId, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByProgram(
            Long programId,
            Pageable pageable
    ) {
        return repository.findByProgramId(programId, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByStatus(
            WelfareApplication.ApplicationStatus status,
            Pageable pageable
    ) {
        return repository.findByStatus(status, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getAllApplications(Pageable pageable) {
        return repository.findAll(pageable)
                .map(this::map);
    }

    @Override
    @Transactional
    public WelfareApplicationResponse updateApplicationStatus(
            Long id,
            WelfareApplication.ApplicationStatus status,
            String remarks
    ) {
        log.info("Updating application id={} status={}", id, status);

        WelfareApplication app = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        app.setStatus(status);

        if (remarks != null) {
            app.setRemarks(remarks);
        }

        WelfareApplication saved = repository.save(app);

        notificationFeignClient.sendNotification(NotificationRequest.builder()
                .recipientId(saved.getCitizenId())
                .entityId(saved.getApplicationId())
                .message("Your application (ID: " + saved.getApplicationId() + ") status has been updated to " + status + ".")
                .category("APPLICATION")
                .build());

        return map(saved);
    }

    @Override
    @Transactional
    public void withdrawApplication(Long id) {
        log.warn("Withdrawing application id={}", id);

        WelfareApplication app = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        app.setStatus(WelfareApplication.ApplicationStatus.CLOSED);
        repository.save(app);
    }

    private WelfareApplicationResponse map(WelfareApplication a) {
        return WelfareApplicationResponse.builder()
                .applicationId(a.getApplicationId())
                .citizenId(a.getCitizenId())
                .programId(a.getProgramId())
                .schemeId(a.getSchemeId())
                .submittedDate(a.getSubmittedDate())
                .status(a.getStatus())
                .remarks(a.getRemarks())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}

@Service
@RequiredArgsConstructor
@Slf4j
public class WelfareApplicationServiceImpl implements WelfareApplicationService {

    private final WelfareApplicationRepository repository;

    @Override
    @Transactional
    public WelfareApplicationResponse submitApplication(WelfareApplicationRequest request) {
        log.info("Submitting application citizenId={}, programId={}",
                request.getCitizenId(), request.getProgramId());

        if (repository.existsByCitizenIdAndProgramId(
                request.getCitizenId(),
                request.getProgramId()
        )) {
            log.warn("Duplicate application attempt citizenId={}, programId={}",
                    request.getCitizenId(), request.getProgramId());
            throw new IllegalStateException("Application already exists for this program");
        }

        WelfareApplication app = WelfareApplication.builder()
                .citizenId(request.getCitizenId())
                .programId(request.getProgramId())
                .schemeId(request.getSchemeId())
                .remarks(request.getRemarks())
                .status(WelfareApplication.ApplicationStatus.SUBMITTED)
                .build();

        WelfareApplication saved = repository.save(app);
        log.info("Application created with id={}", saved.getApplicationId());

        return map(saved);
    }

    @Override
    public WelfareApplicationResponse getApplicationById(Long id) {
        log.debug("Fetching application id={}", id);

        WelfareApplication app = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        return map(app);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByCitizen(
            Long citizenId,
            Pageable pageable
    ) {
        return repository.findByCitizenId(citizenId, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByProgram(
            Long programId,
            Pageable pageable
    ) {
        return repository.findByProgramId(programId, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByStatus(
            WelfareApplication.ApplicationStatus status,
            Pageable pageable
    ) {
        return repository.findByStatus(status, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getAllApplications(Pageable pageable) {
        return repository.findAll(pageable)
                .map(this::map);
    }

    @Override
    @Transactional
    public WelfareApplicationResponse updateApplicationStatus(
            Long id,
            WelfareApplication.ApplicationStatus status,
            String remarks
    ) {
        log.info("Updating application id={} status={}", id, status);

        WelfareApplication app = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        app.setStatus(status);

        if (remarks != null) {
            app.setRemarks(remarks);
        }

        return map(repository.save(app));
    }

    @Override
    @Transactional
    public void withdrawApplication(Long id) {
        log.warn("Withdrawing application id={}", id);

        WelfareApplication app = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        app.setStatus(WelfareApplication.ApplicationStatus.CLOSED);
        repository.save(app);
    }

    private WelfareApplicationResponse map(WelfareApplication a) {
        return WelfareApplicationResponse.builder()
                .applicationId(a.getApplicationId())
                .citizenId(a.getCitizenId())
                .programId(a.getProgramId())
                .schemeId(a.getSchemeId())
                .submittedDate(a.getSubmittedDate())
                .status(a.getStatus())
                .remarks(a.getRemarks())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}