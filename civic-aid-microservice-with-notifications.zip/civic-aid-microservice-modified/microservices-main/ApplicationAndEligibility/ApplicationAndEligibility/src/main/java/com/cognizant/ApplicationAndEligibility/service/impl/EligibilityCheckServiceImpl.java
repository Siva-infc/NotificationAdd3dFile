package com.cognizant.ApplicationAndEligibility.service.impl;

import com.cognizant.ApplicationAndEligibility.entity.EligibilityCheck;
import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import com.cognizant.ApplicationAndEligibility.repository.EligibilityCheckRepository;
import com.cognizant.ApplicationAndEligibility.repository.WelfareApplicationRepository;
import com.cognizant.ApplicationAndEligibility.request.EligibilityCheckRequest;
import com.cognizant.ApplicationAndEligibility.response.EligibilityCheckResponse;
import com.cognizant.ApplicationAndEligibility.service.EligibilityCheckService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class EligibilityCheckServiceImpl implements EligibilityCheckService {

    private final EligibilityCheckRepository checkRepository;
    private final WelfareApplicationRepository welfareApplicationRepository;

    @Override
    @Transactional
    public EligibilityCheckResponse performCheck(EligibilityCheckRequest request) {
        log.info("Performing eligibility check applicationId={}, officerId={}",
                request.getApplicationId(), request.getOfficerId());

        WelfareApplication application = welfareApplicationRepository
                .findById(request.getApplicationId())
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));

        EligibilityCheck check = EligibilityCheck.builder()
                .application(application)
                .officerId(request.getOfficerId())
                .result(request.getResult())
                .notes(request.getNotes())
                .build();

        switch (request.getResult()) {
            case ELIGIBLE -> application.setStatus(WelfareApplication.ApplicationStatus.ELIGIBLE);
            case INELIGIBLE -> application.setStatus(WelfareApplication.ApplicationStatus.INELIGIBLE);
            default -> application.setStatus(WelfareApplication.ApplicationStatus.UNDER_REVIEW);
        }

        welfareApplicationRepository.save(application);
        EligibilityCheck savedCheck = checkRepository.save(check);

        log.info("Eligibility check completed with result={}", savedCheck.getResult());

        return map(savedCheck);
    }

    @Override
    public List<EligibilityCheckResponse> getChecksByApplication(Long applicationId) {
        log.debug("Fetching eligibility checks applicationId={}", applicationId);

        return checkRepository
                .findByApplication_ApplicationId(applicationId)
                .stream()
                .map(this::map)
                .toList();
    }

    @Override
    public EligibilityCheckResponse getLatestCheck(Long applicationId) {
        log.debug("Fetching latest eligibility check applicationId={}", applicationId);

        return checkRepository
                .findTopByApplication_ApplicationIdOrderByDateDesc(applicationId)
                .map(this::map)
                .orElseThrow(() ->
                        new IllegalArgumentException("No eligibility checks found"));
    }

    private EligibilityCheckResponse map(EligibilityCheck e) {
        return EligibilityCheckResponse.builder()
                .checkId(e.getCheckId())
                .applicationId(e.getApplication().getApplicationId())
                .officerId(e.getOfficerId())
                .result(e.getResult())
                .date(e.getDate())
                .notes(e.getNotes())
                .build();
    }
}
