package com.cognizant.ApplicationAndEligibility.service;

import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import com.cognizant.ApplicationAndEligibility.request.WelfareApplicationRequest;
import com.cognizant.ApplicationAndEligibility.response.WelfareApplicationResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface WelfareApplicationService {

        WelfareApplicationResponse submitApplication(WelfareApplicationRequest request);

        WelfareApplicationResponse getApplicationById(Long id);

        Page<WelfareApplicationResponse> getApplicationsByCitizen(Long citizenId, Pageable pageable);

        Page<WelfareApplicationResponse> getApplicationsByProgram(Long programId, Pageable pageable);

        Page<WelfareApplicationResponse> getApplicationsByStatus(
                WelfareApplication.ApplicationStatus status,
                Pageable pageable
        );

        Page<WelfareApplicationResponse> getAllApplications(Pageable pageable);

        WelfareApplicationResponse updateApplicationStatus(
                Long id,
                WelfareApplication.ApplicationStatus status,
                String remarks
        );

        void withdrawApplication(Long id);
}
