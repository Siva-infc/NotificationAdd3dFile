package com.cognizant.ApplicationAndEligibility.controller;

import com.cognizant.ApplicationAndEligibility.request.EligibilityCheckRequest;
import com.cognizant.ApplicationAndEligibility.response.EligibilityCheckResponse;
import com.cognizant.ApplicationAndEligibility.service.EligibilityCheckService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/eligibility-checks")
@RequiredArgsConstructor
@Slf4j
public class EligibilityCheckController {

    private final EligibilityCheckService eligibilityCheckService;

    @PostMapping
    public ResponseEntity<EligibilityCheckResponse> performCheck(
            @Valid @RequestBody EligibilityCheckRequest request
    ) {
        log.info("Performing eligibility check for applicationId={}, officerId={}",
                request.getApplicationId(), request.getOfficerId());

        EligibilityCheckResponse response =
                eligibilityCheckService.performCheck(request);

        log.info("Eligibility check completed with result={}", response.getResult());

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/application/{applicationId}")
    public ResponseEntity<List<EligibilityCheckResponse>> getChecksByApplication(
            @PathVariable Long applicationId
    ) {
        log.debug("Fetching eligibility checks for applicationId={}", applicationId);
        return ResponseEntity.ok(
                eligibilityCheckService.getChecksByApplication(applicationId)
        );
    }

    @GetMapping("/application/{applicationId}/latest")
    public ResponseEntity<EligibilityCheckResponse> getLatestCheck(
            @PathVariable Long applicationId
    ) {
        log.debug("Fetching latest eligibility check for applicationId={}", applicationId);
        return ResponseEntity.ok(
                eligibilityCheckService.getLatestCheck(applicationId)
        );
    }
}