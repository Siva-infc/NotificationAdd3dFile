package com.cognizant.ApplicationAndEligibility.controller;

import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import com.cognizant.ApplicationAndEligibility.request.WelfareApplicationRequest;
import com.cognizant.ApplicationAndEligibility.response.WelfareApplicationResponse;
import com.cognizant.ApplicationAndEligibility.service.WelfareApplicationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/applications")
@RequiredArgsConstructor
@Slf4j
public class WelfareApplicationController {

    private final WelfareApplicationService applicationService;

    /* =========================
       Submit Application
       ========================= */
    @PostMapping
    @PreAuthorize("hasAnyRole('CITIZEN','SERVICE')")
    public ResponseEntity<WelfareApplicationResponse> submitApplication(
            @Valid @RequestBody WelfareApplicationRequest request
    ) {
        log.info("Submitting application for citizenId={}, programId={}",
                request.getCitizenId(), request.getProgramId());

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(applicationService.submitApplication(request));
    }

    /* =========================
       Get Applications by Citizen
       ========================= */
    @GetMapping("/citizen/{citizenId}")
    @PreAuthorize("hasAnyRole('CITIZEN','SERVICE','ADMINISTRATOR')")
    public ResponseEntity<Page<WelfareApplicationResponse>> getApplicationsByCitizen(
            @PathVariable Long citizenId,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        log.debug("Fetching applications for citizenId={}", citizenId);
        return ResponseEntity.ok(
                applicationService.getApplicationsByCitizen(citizenId, pageable)
        );
    }

    /* =========================
       Get Application by ID
       ========================= */
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<WelfareApplicationResponse> getApplicationById(
            @PathVariable Long id
    ) {
        log.debug("Fetching application by id={}", id);
        return ResponseEntity.ok(
                applicationService.getApplicationById(id)
        );
    }

    /* =========================
       Get All Applications
       ========================= */
    @GetMapping
    @PreAuthorize("""
        hasAnyRole(
            'WELFARE_OFFICER',
            'PROGRAM_MANAGER',
            'ADMINISTRATOR',
            'COMPLIANCE_OFFICER',
            'GOVERNMENT_AUDITOR'
        )
        """)
    public ResponseEntity<Page<WelfareApplicationResponse>> getAllApplications(
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(required = false) WelfareApplication.ApplicationStatus status,
            @RequestParam(required = false) Long programId
    ) {
        if (status != null) {
            return ResponseEntity.ok(
                    applicationService.getApplicationsByStatus(status, pageable)
            );
        }

        if (programId != null) {
            return ResponseEntity.ok(
                    applicationService.getApplicationsByProgram(programId, pageable)
            );
        }

        return ResponseEntity.ok(
                applicationService.getAllApplications(pageable)
        );
    }

    /* =========================
       Update Application Status
       ========================= */
    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<WelfareApplicationResponse> updateApplicationStatus(
            @PathVariable Long id,
            @RequestParam WelfareApplication.ApplicationStatus status,
            @RequestParam(required = false) String remarks
    ) {
        log.info("Updating application id={} to status={}", id, status);
        return ResponseEntity.ok(
                applicationService.updateApplicationStatus(id, status, remarks)
        );
    }

    /* =========================
       Withdraw Application
       ========================= */
    @PatchMapping("/{id}/withdraw")
    @PreAuthorize("hasAnyRole('CITIZEN','SERVICE')")
    public ResponseEntity<String> withdrawApplication(
            @PathVariable Long id
    ) {
        log.warn("Withdrawing application id={}", id);
        applicationService.withdrawApplication(id);
        return ResponseEntity.ok("Application withdrawn");
    }
}