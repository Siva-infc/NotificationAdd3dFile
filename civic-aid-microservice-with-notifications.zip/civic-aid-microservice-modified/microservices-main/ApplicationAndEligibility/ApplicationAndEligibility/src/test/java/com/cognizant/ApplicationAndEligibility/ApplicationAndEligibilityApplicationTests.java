package com.cognizant.ApplicationAndEligibility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationAndEligibilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
