package com.cognizant.ProgramAndScheme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramAndSchemeApplicationTests {

	@Test
	void contextLoads() {
	}

}
