package com.cognizant.Notification.controller;

import com.cognizant.Notification.dto.request.NotificationRequest;
import com.cognizant.Notification.dto.response.NotificationResponse;
import com.cognizant.Notification.service.impl.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
@PreAuthorize("isAuthenticated()")
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping("/send")
    public ResponseEntity<Void> sendNotification(
            @RequestBody NotificationRequest request
    ) {
        notificationService.sendNotification(
                request.getRecipientId(),
                request.getEntityId(),
                request.getMessage(),
                request.getCategory()
        );
        return ResponseEntity.ok().build();
    }

    @GetMapping("/recipient/{recipientId}")
    public ResponseEntity<Page<NotificationResponse>> getNotifications(
            @PathVariable Long recipientId,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        return ResponseEntity.ok(
                notificationService.getNotifications(recipientId, pageable)
        );
    }

    @GetMapping("/recipient/{recipientId}/unread")
    public ResponseEntity<Page<NotificationResponse>> getUnreadNotifications(
            @PathVariable Long recipientId,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        return ResponseEntity.ok(
                notificationService.getUnreadNotifications(recipientId, pageable)
        );
    }

    @GetMapping("/recipient/{recipientId}/unread/count")
    public ResponseEntity<Long> getUnreadCount(
            @PathVariable Long recipientId
    ) {
        return ResponseEntity.ok(
                notificationService.getUnreadCount(recipientId)
        );
    }

    @PatchMapping("/{id}/read")
    public ResponseEntity<String> markAsRead(@PathVariable Long id) {
        notificationService.markAsRead(id);
        return ResponseEntity.ok("Notification marked as read");
    }

    @PatchMapping("/recipient/{recipientId}/read-all")
    public ResponseEntity<Integer> markAllAsRead(
            @PathVariable Long recipientId
    ) {
        return ResponseEntity.ok(
                notificationService.markAllAsRead(recipientId)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteNotification(@PathVariable Long id) {
        notificationService.deleteNotification(id);
        return ResponseEntity.ok("Notification deleted");
    }
}