package com.cognizant.Notification.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long notificationId;

    /** Receiver ID (user / officer / system) */
    @Column(nullable = false)
    private Long recipientId;

    /** Related entity reference (optional) */
    private Long entityId;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String message;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NotificationCategory category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private NotificationStatus status = NotificationStatus.UNREAD;

    @CreationTimestamp
    private LocalDateTime createdAt;

    private LocalDateTime readAt;

    public enum NotificationCategory {
        APPLICATION,
        DISBURSEMENT,
        COMPLIANCE,
        PROGRAM,
        PAYMENT,
        SYSTEM
    }

    public enum NotificationStatus {
        UNREAD,
        READ,
        ARCHIVED
    }
}
