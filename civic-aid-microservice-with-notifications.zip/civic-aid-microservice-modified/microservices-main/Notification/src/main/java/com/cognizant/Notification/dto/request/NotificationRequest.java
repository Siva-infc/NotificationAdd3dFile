package com.cognizant.Notification.dto.request;

import com.cognizant.Notification.entity.Notification;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationRequest {

    private Long recipientId;
    private Long entityId;
    private String message;
    private Notification.NotificationCategory category;
}
