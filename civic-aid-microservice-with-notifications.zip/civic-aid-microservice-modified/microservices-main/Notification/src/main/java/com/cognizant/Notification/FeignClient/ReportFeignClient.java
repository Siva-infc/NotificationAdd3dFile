package com.cognizant.Notification.FeignClient;

import com.cognizant.Notification.dto.response.ReportDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "report-service", path = "/reports")
public interface ReportFeignClient {

    @GetMapping("/{id}")
    ReportDto getReportById(@PathVariable Long id);
}