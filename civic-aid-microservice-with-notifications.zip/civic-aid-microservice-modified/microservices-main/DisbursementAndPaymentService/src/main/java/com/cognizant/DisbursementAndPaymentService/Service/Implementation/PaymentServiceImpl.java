package com.cognizant.DisbursementAndPaymentService.Service.Implementation;

import com.cognizant.DisbursementAndPaymentService.Entity.Disbursement;
import com.cognizant.DisbursementAndPaymentService.Entity.Payment;
import com.cognizant.DisbursementAndPaymentService.FeignClient.NotificationFeignClient;
import com.cognizant.DisbursementAndPaymentService.Repository.DisbursementRepository;
import com.cognizant.DisbursementAndPaymentService.Repository.PaymentRepository;
import com.cognizant.DisbursementAndPaymentService.Request.NotificationRequest;
import com.cognizant.DisbursementAndPaymentService.Request.PaymentRequest;
import com.cognizant.DisbursementAndPaymentService.Response.PaymentResponse;
import com.cognizant.DisbursementAndPaymentService.Service.PaymentService;
import com.cognizant.DisbursementAndPaymentService.Exception.ResourceNotFoundException;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepo;
    private final DisbursementRepository disbursementRepo;
    private final NotificationFeignClient notificationFeignClient;

    @Override
    public PaymentResponse initiatePayment(PaymentRequest r) {

        Disbursement d = disbursementRepo.findById(r.getDisbursementId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Disbursement", r.getDisbursementId()));

        Payment p = Payment.builder()
                .disbursement(d)
                .method(r.getMethod())
                .amount(r.getAmount())
                .transactionReference(r.getTransactionReference())
                .bankAccountNumber(r.getBankAccountNumber())
                .walletId(r.getWalletId())
                .build();

        d.setStatus(Disbursement.DisbursementStatus.PROCESSING);

        Payment saved = paymentRepo.save(p);

        notificationFeignClient.sendNotification(NotificationRequest.builder()
                .recipientId(d.getCitizenId())
                .entityId(saved.getPaymentId())
                .message("Payment of " + saved.getAmount() + " has been initiated via " + saved.getMethod() + " for disbursement (ID: " + d.getDisbursementId() + ").")
                .category("PAYMENT")
                .build());

        return map(saved);
    }

    @Override
    public PaymentResponse updateStatus(Long id, Payment.PaymentStatus status) {

        Payment p = paymentRepo.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Payment", id));

        p.setStatus(status);

        if (status == Payment.PaymentStatus.SUCCESS) {
            p.getDisbursement()
                    .setStatus(Disbursement.DisbursementStatus.COMPLETED);
        }

        Payment saved = paymentRepo.save(p);

        notificationFeignClient.sendNotification(NotificationRequest.builder()
                .recipientId(saved.getDisbursement().getCitizenId())
                .entityId(saved.getPaymentId())
                .message("Your payment (ID: " + saved.getPaymentId() + ") status has been updated to " + status + ".")
                .category("PAYMENT")
                .build());

        return map(saved);
    }

    @Override
    public List<PaymentResponse> getByDisbursement(Long disbursementId) {

        return paymentRepo
                .findByDisbursement_DisbursementId(disbursementId)
                .stream()
                .map(this::map)
                .toList();
    }

    private PaymentResponse map(Payment p) {

        return PaymentResponse.builder()
                .paymentId(p.getPaymentId())
                .disbursementId(p.getDisbursement().getDisbursementId())
                .method(p.getMethod())
                .amount(p.getAmount())
                .status(p.getStatus())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}

    @Override
    public PaymentResponse initiatePayment(PaymentRequest r) {

        Disbursement d = disbursementRepo.findById(r.getDisbursementId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Disbursement", r.getDisbursementId()));

        Payment p = Payment.builder()
                .disbursement(d)
                .method(r.getMethod())
                .amount(r.getAmount())
                .transactionReference(r.getTransactionReference())
                .bankAccountNumber(r.getBankAccountNumber())
                .walletId(r.getWalletId())
                .build();

        d.setStatus(Disbursement.DisbursementStatus.PROCESSING);

        return map(paymentRepo.save(p));
    }

    @Override
    public PaymentResponse updateStatus(Long id, Payment.PaymentStatus status) {

        Payment p = paymentRepo.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Payment", id));

        p.setStatus(status);

        if (status == Payment.PaymentStatus.SUCCESS) {
            p.getDisbursement()
                    .setStatus(Disbursement.DisbursementStatus.COMPLETED);
        }

        return map(paymentRepo.save(p));
    }

    @Override
    public List<PaymentResponse> getByDisbursement(Long disbursementId) {

        return paymentRepo
                .findByDisbursement_DisbursementId(disbursementId)
                .stream()
                .map(this::map)
                .toList();
    }

    private PaymentResponse map(Payment p) {

        return PaymentResponse.builder()
                .paymentId(p.getPaymentId())
                .disbursementId(p.getDisbursement().getDisbursementId())
                .method(p.getMethod())
                .amount(p.getAmount())
                .status(p.getStatus())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}