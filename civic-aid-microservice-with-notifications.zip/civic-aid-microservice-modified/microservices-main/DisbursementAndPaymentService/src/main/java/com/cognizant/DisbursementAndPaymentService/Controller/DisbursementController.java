package com.cognizant.DisbursementAndPaymentService.Controller;

import com.cognizant.DisbursementAndPaymentService.Entity.Disbursement;
import com.cognizant.DisbursementAndPaymentService.Request.DisbursementRequest;
import com.cognizant.DisbursementAndPaymentService.Response.DisbursementResponse;
import com.cognizant.DisbursementAndPaymentService.Service.DisbursementService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/disbursements")
@RequiredArgsConstructor
public class DisbursementController {

    private final DisbursementService service;

    @PostMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','SEVICE')")
    public ResponseEntity<DisbursementResponse> create(
            @Valid @RequestBody DisbursementRequest request) {

        log.info("create disbursement");
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(service.createDisbursement(request));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','SEVICE')")
    public ResponseEntity<DisbursementResponse> getById(@PathVariable Long id) {
        log.info("getById controller");
        return ResponseEntity.ok(service.getById(id));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','SEVICE')")
    public ResponseEntity<Page<DisbursementResponse>> getAll(
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(required = false)
            Disbursement.DisbursementStatus status) {
        log.info("getAll controller");
        Page<DisbursementResponse> page =
                (status != null)
                        ? service.getByStatus(status, pageable)
                        : service.getAll(pageable);

        return ResponseEntity.ok(page);
    }

    @GetMapping("/application/{applicationId}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','SEVICE')")
    public ResponseEntity<List<DisbursementResponse>> getByApplication(
            @PathVariable Long applicationId) {
        log.info("getbyapplication");
        return ResponseEntity.ok(service.getByApplication(applicationId));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','SEVICE')")
    public ResponseEntity<DisbursementResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam Disbursement.DisbursementStatus status) {
        log.info("updatestatus");
        return ResponseEntity.ok(service.updateStatus(id, status));

    }
}