package com.cognizant.DisbursementAndPaymentService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class DisbursementAndPaymentServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(DisbursementAndPaymentServiceApplication.class, args);
	}

}
