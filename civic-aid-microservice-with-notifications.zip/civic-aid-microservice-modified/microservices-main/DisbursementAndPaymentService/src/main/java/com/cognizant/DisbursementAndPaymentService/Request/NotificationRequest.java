package com.cognizant.DisbursementAndPaymentService.Request;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationRequest {

    private Long recipientId;
    private Long entityId;
    private String message;
    private String category;
}
