package com.cognizant.DisbursementAndPaymentService.Service.Implementation;

import com.cognizant.DisbursementAndPaymentService.Entity.Disbursement;
import com.cognizant.DisbursementAndPaymentService.FeignClient.NotificationFeignClient;
import com.cognizant.DisbursementAndPaymentService.Repository.DisbursementRepository;
import com.cognizant.DisbursementAndPaymentService.Request.DisbursementRequest;
import com.cognizant.DisbursementAndPaymentService.Request.NotificationRequest;
import com.cognizant.DisbursementAndPaymentService.Response.DisbursementResponse;
import com.cognizant.DisbursementAndPaymentService.Service.DisbursementService;
import com.cognizant.DisbursementAndPaymentService.Exception.ResourceNotFoundException;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DisbursementServiceImpl implements DisbursementService {

    private final DisbursementRepository repo;
    private final NotificationFeignClient notificationFeignClient;

    @Override
    @Transactional
    public DisbursementResponse createDisbursement(DisbursementRequest r) {
        Disbursement d = Disbursement.builder()
                .applicationId(r.getApplicationId())
                .citizenId(r.getCitizenId())
                .programId(r.getProgramId())
                .amount(r.getAmount())
                .remarks(r.getRemarks())
                .build();

        Disbursement saved = repo.save(d);

        notificationFeignClient.sendNotification(NotificationRequest.builder()
                .recipientId(saved.getCitizenId())
                .entityId(saved.getDisbursementId())
                .message("A disbursement of " + saved.getAmount() + " has been created for your application (ID: " + saved.getApplicationId() + ").")
                .category("DISBURSEMENT")
                .build());

        return map(saved);
    }

    @Override
    public DisbursementResponse getById(Long id) {
        return map(repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Disbursement", id)));
    }

    @Override
    public List<DisbursementResponse> getByApplication(Long appId) {
        return repo.findByApplicationId(appId)
                .stream()
                .map(this::map)
                .toList();
    }

    @Override
    public Page<DisbursementResponse> getByStatus(
            Disbursement.DisbursementStatus status,
            Pageable pageable) {
        return repo.findByStatus(status, pageable).map(this::map);
    }

    @Override
    public Page<DisbursementResponse> getAll(Pageable pageable) {
        return repo.findAll(pageable).map(this::map);
    }

    @Override
    @Transactional
    public DisbursementResponse updateStatus(
            Long id,
            Disbursement.DisbursementStatus status) {

        Disbursement disbursement = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Disbursement", id));

        disbursement.setStatus(status);
        Disbursement saved = repo.save(disbursement);

        notificationFeignClient.sendNotification(NotificationRequest.builder()
                .recipientId(saved.getCitizenId())
                .entityId(saved.getDisbursementId())
                .message("Your disbursement (ID: " + saved.getDisbursementId() + ") status has been updated to " + status + ".")
                .category("DISBURSEMENT")
                .build());

        return map(saved);
    }

    private DisbursementResponse map(Disbursement d) {
        return DisbursementResponse.builder()
                .disbursementId(d.getDisbursementId())
                .applicationId(d.getApplicationId())
                .citizenId(d.getCitizenId())
                .programId(d.getProgramId())
                .amount(d.getAmount())
                .status(d.getStatus())
                .remarks(d.getRemarks())
                .createdAt(d.getCreatedAt())
                .updatedAt(d.getUpdatedAt())
                .build();
    }
}
