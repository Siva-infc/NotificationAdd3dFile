package com.cognizant.DisbursementAndPaymentService.FeignClient;

import com.cognizant.DisbursementAndPaymentService.Request.NotificationRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notificationservice", path = "/notifications")
public interface NotificationFeignClient {

    @PostMapping("/send")
    void sendNotification(@RequestBody NotificationRequest request);
}
