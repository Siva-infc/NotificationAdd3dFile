package com.cognizant.DisbursementAndPaymentService.Service;

import com.cognizant.DisbursementAndPaymentService.Request.PaymentRequest;
import com.cognizant.DisbursementAndPaymentService.Response.PaymentResponse;
import com.cognizant.DisbursementAndPaymentService.Entity.Payment;
import org.springframework.data.domain.Page;

import java.awt.print.Pageable;
import java.util.List;

public interface PaymentService {
    PaymentResponse initiatePayment(PaymentRequest request);
    PaymentResponse updateStatus(Long id, Payment.PaymentStatus status);
    List<PaymentResponse> getByDisbursement(Long disbursementId);

}