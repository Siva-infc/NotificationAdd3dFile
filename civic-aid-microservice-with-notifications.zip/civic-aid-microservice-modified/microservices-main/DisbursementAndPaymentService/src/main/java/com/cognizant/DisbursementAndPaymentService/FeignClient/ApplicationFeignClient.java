package com.cognizant.DisbursementAndPaymentService.FeignClient;

import com.cognizant.DisbursementAndPaymentService.Response.WelfareApplicationResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "application-service", path = "/applications")
public interface ApplicationFeignClient {

    @GetMapping("/{id}")
    WelfareApplicationResponse getApplicationById(@PathVariable Long id);

    @GetMapping("/{id}/status")
    String getApplicationStatus(@PathVariable Long id);
}