package com.cognizant.civicaid.userservice.service;

import com.cognizant.civicaid.userservice.dto.RegisterRequestDto;
import com.cognizant.civicaid.userservice.dto.RegisterResponseDto;
import com.cognizant.civicaid.userservice.dto.UserDto;

import java.util.List;

public interface UserService {

    RegisterResponseDto createUsers(RegisterRequestDto registerRequestDto);
    UserDto findByEmail(String email);

    List<RegisterResponseDto>getAllUser();

    void deleteUser(Long id);

    RegisterResponseDto getUserById(Long id);
}
